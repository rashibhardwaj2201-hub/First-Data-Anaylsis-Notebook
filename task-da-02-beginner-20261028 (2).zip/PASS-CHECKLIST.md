# Required checks
- [ ] Load the supplied CSV and show its first rows.
- [ ] Count missing values and explain one cleaning decision.
- [ ] Calculate total revenue and average order value.
- [ ] Create one category bar chart and write two observations.

Optional, not required for approval: Distributions, IQR, boxplots and correlation heatmaps.
