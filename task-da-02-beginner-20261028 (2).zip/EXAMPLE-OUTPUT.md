# Target shape, not a substitute for your work
One view-only notebook link including regenerated outputs.

Show each required check and explain one decision in your own words.
Sales CSV expected: 8 orders, revenue 4700, average 587.5. SQL fixture expected: expensive products book/bag, West count 2, sum 2000, customers B before A, average product price 633.333… (rounded output allowed).



