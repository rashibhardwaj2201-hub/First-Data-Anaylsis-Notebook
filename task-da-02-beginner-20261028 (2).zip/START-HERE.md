# Milestone 3: Your first analysis notebook

Revision: beginner-20261028
Run and complete a supplied Colab/Jupyter notebook to inspect a small synthetic sales dataset.

Preparation: The supplied notebook; browser Colab avoids a local Python installation.
Hands-on estimate: 3–5 hours; installation/download/render time may be extra.

Start with these files:
- sales.csv
- sales-dirty.csv
- practice.sql
- analysis.ipynb
- SPREADSHEET-GUIDE.md

Read guide.md and PASS-CHECKLIST.md. Complete TODOs and record your own observations; downloading a pack is not task completion. Use only fictional/local authorised practice data. View-only source folders and screenshots are accepted where the stated task permits them; public social accounts are not compulsory.
