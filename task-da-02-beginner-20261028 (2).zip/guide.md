Download the self-contained starter pack by opening https://api.edbytes.in/api/v1/public/curriculum/TASK-DA-02/starter.zip in your browser. Extract it and read START-HERE.md. All practice records and examples in the pack are synthetic.

Preparation: The supplied notebook; browser Colab avoids a local Python installation. Estimated hands-on time: 3–5 hours. Downloads, installations and final rendering may need additional time; take breaks and ask support if setup fails.

Open the named starting files described in START-HERE.md. Keep an untouched copy and save your own work in a separate folder. EXAMPLE-OUTPUT.md explains the target result without replacing your own work.

Required check 1: Load the supplied CSV and show its first rows.

Required check 2: Count missing values and explain one cleaning decision.

Required check 3: Calculate total revenue and average order value.

Required check 4: Create one category bar chart and write two observations.

Use PASS-CHECKLIST.md to verify only the required checks. Optional stretch: Distributions, IQR, boxplots and correlation heatmaps. Skipping stretch work does not reduce completion eligibility.

Test one ordinary case and one relevant boundary or failure case using dummy data. Explain what you changed and one thing you learned; do not upload real passwords, tokens, contact lists or patient/financial records.

Submit One view-only notebook link including regenerated outputs. Put any companion source/demo link in the note. Confirm view-only access in a private browser window; public social posting and a public GitHub account are not compulsory. Pending or approved evidence stays locked until a mentor requests a revision.
